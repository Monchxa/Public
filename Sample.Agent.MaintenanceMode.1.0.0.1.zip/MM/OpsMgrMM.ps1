﻿# script constants
$SCRIPT_NAME = "OpsMgrMM.ps1"
$SCRIPT_Version = "1.0"

# event constants
$EVENT_TYPE_SUCCESS = 0
$EVENT_TYPE_ERROR = 1
$EVENT_TYPE_WARNING = 2
$EVENT_TYPE_INFORMATION = 4

$EVENT_ID_SUCCESS = 997           # use IDs in the range 1 - 1000
$EVENT_ID_SCRIPTERROR = 999        # then you can use eventcreate.exe for testing
$EVENT_ID_PROCESSING_ERROR = 998

$msg = ""

cls

[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

function CheckMaintenance($time)
{
	
	$objProgressForm = New-Object System.Windows.Forms.Form 
	$objProgressForm.Text = "Check for Maintenance Mode Events"
	$objProgressForm.Location = New-Object System.Drawing.Size (0,0)
	$objProgressForm.Size = New-Object System.Drawing.Size(240,70) 
	#$objProgressForm.StartPosition = "CenterScreen"
	#$objProgressForm.FormBorderStyle = 'FixedDialog'
	$objProgressForm.ControlBox =$false
	
	$countdown = New-TimeSpan -Minutes 5
	$timespansec = New-TimeSpan -Seconds 1
	
	$objComment = New-Object System.Windows.Forms.Label
	$objComment.Location = New-Object System.Drawing.Size(20,10)
	$objComment.Size = New-Object System.Drawing.Size(200,20)
	$objComment.Text = "Please wait... Time remaining: " + $countdown.minutes + ":" + $countdown.Seconds
	$objComment.BackColor = [System.Drawing.Color]::'Transparent'
	$objProgressForm.Controls.Add($objComment)
		
	[void] $objProgressForm.Show()
	
	$timer = new-object System.Windows.Forms.Timer
	$timer.Enabled = $false
	$timer.Interval = 100
	
	$time = (Get-Date)
	$MaintenanceTimeout = 300
    $foundevent= $false 
	For ($i=1;(($MaintenanceTimeout -gt $i)-and ($foundevent -eq $false));$i++)
	{
        $event = get-eventlog -logname 'operations manager' -newest 1 -instanceID 1073743039
    	If ($event.TimeGenerated -gt $time){$foundevent=$true}
		$objComment.Text = "Please wait... Time remaining: " + $countdown.minutes + ":" + $countdown.Seconds
		$objProgressForm.Update()
		Start-Sleep -Seconds 1
		$countdown = $countdown.subtract($timespansec)
	}
	$objProgressForm.Close()
	$objProgressForm.Dispose()
	If ($foundevent){[windows.forms.messagebox]::Show("Server is in maintenance mode!")}
	Else {[windows.forms.messagebox]::Show("Maintenance mode still not set, please check Operations Manager console")}
}

function Shutdown ()
{
	$result = $Null
	$result = Stop-Computer
	If ($result -eq $Null){[windows.forms.messagebox]::Show("Shutdown initialized successfully!")}
	Else {[windows.forms.messagebox]::Show("Failed to initialize shutdown!")}
}

function Reboot()
{
	$result = $Null
	$result = Restart-Computer
	If ($result -eq $Null){[windows.forms.messagebox]::Show("Reboot initialized successfully!")}
	Else {[windows.forms.messagebox]::Show("Failed to initialize reboot!")}
}

function WriteMaintenanceToLog ($Reason, $Duration, $Comment)
{
	$objForm.Dispose()
	$time = get-date
	$result = $Null
	switch ($Duration){
	'10 minutes' {$Duration = "10"; break}
	'30 minutes' {$Duration = "30"; break}
	'1 hour' {$Duration = "60"; break}
	'2 hours' {$Duration = "120"; break}
	'4 hours' {$Duration = "240"; break}
	'8 hours' {$Duration = "480"; break}
	'12 hours' {$Duration = "720"; break}
	'1 day' {$Duration = "1440"; break}
	'2 days' {$Duration = "2880"; break}
	'1 week' {$Duration = "10080"; break}
	'2 weeks' {$Duration = "20160"; break}
	'4 weeks' {$Duration = "40320"; break}
	}	

	$msg = ";" + $Duration + ";" + $Reason + ";" + $Comment
	# create MOM Script API COM object 
	$api = New-Object -comObject "MOM.ScriptAPI"; 
	# write informational event with maintenance mode info
	$result = $api.LogScriptEvent($SCRIPT_NAME + " " + $SCRIPT_VERSION,$EVENT_ID_SUCCESS,$EVENT_TYPE_INFORMATION,$msg)
	If ($result -eq $Null){
			[windows.forms.messagebox]::Show("Successfully written to OpsManager Event Log!")
			CheckMaintenance -time $time
			$result = $True}
	Else {
			[windows.forms.messagebox]::Show("Failed to write to OpsManager Event Log!")
			$result = $False}
}

function mainform ()
{
	$objForm = New-Object System.Windows.Forms.Form 
	$objForm.Text = "Sample Operations Manager Maintenance Mode"
	$objForm.Size = New-Object System.Drawing.Size(650,460) 
	$objForm.StartPosition = "CenterScreen"
	$objForm.FormBorderStyle = 'FixedDialog'
	$objForm.ControlBox =$false
	$objForm.BackGroundImage =  [System.Drawing.Image]::FromFile('c:\mm\OpsMgr2012.png')
	$objForm.BackGroundImageLayout = 0
	
	$objForm.KeyPreview = $True
	$objForm.Add_KeyDown({if ($_.KeyCode -eq "Enter") 
	{
		$objForm.Close()
		WriteMaintenanceToLog -Reason ($objReasonBox.Text.Replace(" ", "")) -Duration $objDurationBox.Text -Comment (";;" + $objCommentInput.Text + $user + ";" + (Get-Date))
		}})
	$objForm.Add_KeyDown({if ($_.KeyCode -eq "Escape") 
	    {$objForm.Close()}})

	$MaintenanceButton = New-Object System.Windows.Forms.Button
	$MaintenanceButton.Location = New-Object System.Drawing.Size(150,400)
	$MaintenanceButton.Size = New-Object System.Drawing.Size(140,23)
	$MaintenanceButton.Text = "Maintenance Only"
	$MaintenanceButton.Add_Click({
		$objForm.Close()
		WriteMaintenanceToLog -Reason ($objReasonBox.Text.Replace(" ", "")) -Duration $objDurationBox.Text -Comment (";;" + $objCommentInput.Text + ":" + $user + ";" + (Get-Date))

	})
	$objForm.Controls.Add($MaintenanceButton)
	
	$ShutdownButton = New-Object System.Windows.Forms.Button
	$ShutdownButton.Location = New-Object System.Drawing.Size(300,400)
	$ShutdownButton.Size = New-Object System.Drawing.Size(80,23)
	$ShutdownButton.Text = "Shutdown"
	$ShutdownButton.Add_Click({
		$objForm.Close()
		If (WriteMaintenanceToLog -Reason ($objReasonBox.Text.Replace(" ", "")) -Duration $objDurationBox.Text -Comment (";;" + $objCommentInput.Text + ":" + $user + ";" + (Get-Date))){Shutdown}
	})
	$objForm.Controls.Add($ShutdownButton)
	
	$RebootButton = New-Object System.Windows.Forms.Button
	$RebootButton.Location = New-Object System.Drawing.Size(390,400)
	$RebootButton.Size = New-Object System.Drawing.Size(80,23)
	$RebootButton.Text = "Reboot"
	$RebootButton.Add_Click({
		$objForm.Close()
		If (WriteMaintenanceToLog -Reason ($objReasonBox.Text.Replace(" ", "")) -Duration $objDurationBox.Text -Comment (";;" + $objCommentInput.Text + ":" + $user + ";" + (Get-Date))){Reboot}
	})
	$objForm.Controls.Add($RebootButton)

	$CancelButton = New-Object System.Windows.Forms.Button
	$CancelButton.Location = New-Object System.Drawing.Size(480,400)
	$CancelButton.Size = New-Object System.Drawing.Size(75,23)
	$CancelButton.Text = "Cancel"
	$CancelButton.Add_Click({$objForm.Close()})
	$objForm.Controls.Add($CancelButton)

	$objLabelImage = New-Object System.Windows.Forms.Label
	$objLabelImage.Location = New-Object System.Drawing.Size(400,10)
	$objLabelImage.Size = New-Object System.Drawing.Size(220,45)
	# change logo!
	$objLabelImage.Backgroundimage = [System.Drawing.Image]::FromFile('c:\mm\logo.gif')
	$objLabelImage.BackColor = [System.Drawing.Color]::'Transparent'
	$objForm.Controls.Add($objLabelImage)

	$objLabelGen = New-Object System.Windows.Forms.Label
	$objLabelGen.Location = New-Object System.Drawing.Size(50,160)
	$objLabelGen.Size = New-Object System.Drawing.Size(500,100)
	$objLabelGen.Text = "Please use this tool to set this server into maintenance mode.`n`nIf you are running tests, install new software or perform any other action which puts this machine out of production, this tool will avoid unnecessary alerts which otherwise would trigger actions by the service desk.`n`nThank you for your assistance!"
	$objLabelGen.BackColor = [System.Drawing.Color]::'Transparent'
	$objForm.Controls.Add($objLabelGen)


	$objDuration = New-Object System.Windows.Forms.Label
	$objDuration.Location = New-Object System.Drawing.Size(50,280) 
	$objDuration.Size = New-Object System.Drawing.Size(100,20) 
	$objDuration.Text = "Duration: "
	$objDuration.BackColor = [System.Drawing.Color]::'Transparent'
	$objForm.Controls.Add($objDuration) 

	$objDurationBox = New-Object System.Windows.Forms.ComboBox
	$objDurationBox.DropDownStyle = 'DropDownList'
	$objDurationBox.Name = 'Duration'
	$objDurationBox.Location = New-Object System.Drawing.Size(160,280) 
	$objDurationBox.Size = New-Object System.Drawing.Size(100,20) 
	$objDurationBox.Items.Add('10 minutes')|Out-Null
	$objDurationBox.Items.Add('30 minutes')|Out-Null
	$objDurationBox.Items.Add('1 hour')|Out-Null
	$objDurationBox.Items.Add('2 hours')|Out-Null
	$objDurationBox.Items.Add('4 hours')|Out-Null
	$objDurationBox.Items.Add('8 hours')|Out-Null
	$objDurationBox.Items.Add('12 hours')|Out-Null
	$objDurationBox.Items.Add('1 day')|Out-Null
	$objDurationBox.Items.Add('2 days')|Out-Null
	$objDurationBox.Items.Add('1 week')|Out-Null
	$objDurationBox.Items.Add('2 weeks')|Out-Null
	$objDurationBox.Items.Add('4 weeks')|Out-Null
	$objDurationBox.SelectedIndex = 0
	$objForm.Controls.Add($objDurationBox) 

	$objReason = New-Object System.Windows.Forms.Label
	$objReason.Location = New-Object System.Drawing.Size(50,310) 
	$objReason.Size = New-Object System.Drawing.Size(100,20) 
	$objReason.Text = "Reason:"
	$objReason.BackColor = [System.Drawing.Color]::'Transparent'
	$objForm.Controls.Add($objReason) 

	$objReasonBox = New-Object System.Windows.Forms.ComboBox
	$objreasonbox.DropDownStyle = 'DropDownList'
	$objReasonBox.Items.Add('Application Installation')|Out-Null
	$objReasonBox.Items.Add('Application Unresponsive')|Out-Null
	$objReasonBox.Items.Add('Loss Of Network Connectivity')|Out-Null
	$objReasonBox.Items.Add('Planned Application Maintenance')|Out-Null
	$objReasonBox.Items.Add('PlannedHardwareInstallation')|Out-Null
	$objReasonBox.Items.Add('PlannedOperatingSystemReconfiguration')|Out-Null
	$objReasonBox.Items.Add('PlannedOther')|Out-Null
	$objReasonBox.Items.Add('Security Issue')|Out-Null
	$objReasonBox.Items.Add('Unplanned Application Maintenance')|Out-Null
	$objReasonBox.Items.Add('Unplanned Hardware Maintenance')|Out-Null
	$objReasonBox.Items.Add('Unplanned Other')|Out-Null
	$objreasonbox.SelectedIndex = 0
	$objReasonBox.Name = 'Reason'
	$objReasonBox.Location = New-Object System.Drawing.Size(160,310) 
	$objReasonBox.Size = New-Object System.Drawing.Size(200,20) 
	$objForm.Controls.Add($objReasonBox) 

	$objComment = New-Object System.Windows.Forms.Label
	$objComment.Location = New-Object System.Drawing.Size(50,340) 
	$objComment.Size = New-Object System.Drawing.Size(100,20) 
	$objComment.Text = "Comment:"
	$objComment.BackColor = [System.Drawing.Color]::'Transparent'
	$objForm.Controls.Add($objComment) 

	$objCommentInput = New-Object System.Windows.Forms.TextBox 
	$objCommentInput.Location = New-Object System.Drawing.Size(160,340) 
	$objCommentInput.Size = New-Object System.Drawing.Size(200,20) 
	$objForm.Controls.Add($objCommentInput) 

	$objContact = New-Object System.Windows.Forms.Label
	$objContact.Location = New-Object System.Drawing.Size(50,370)
	$objContact.Size = New-Object System.Drawing.Size(500,20)
	# change email address!
	$objContact.Text = "Please contact address@company.com for assistance."
	$objContact.BackColor = [System.Drawing.Color]::'Transparent'
	$objForm.Controls.Add($objContact)

	$objUsername = New-Object System.Windows.Forms.Label
	$objUsername.Location = New-Object System.Drawing.Size(50,400) 
	$objUsername.Size = New-Object System.Drawing.Size(100,30) 
	$objUsername.BackColor = [System.Drawing.Color]::'Transparent'
	$user = (Get-Content env:userdomain) + "\"+ (Get-Content env:username)
	$objUsername.Text = $user
	$objForm.Controls.Add($objUsername) 
	
	$objForm.Topmost = $False

	$objForm.Add_Shown({$objForm.Activate()})
	[void] $objForm.ShowDialog()
}

mainform
